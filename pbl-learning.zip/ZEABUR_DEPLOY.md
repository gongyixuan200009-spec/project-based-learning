# Zeabur 部署完整指南

本指南详细说明如何将 PBL Learning Platform 部署到 Zeabur 平台。

## 什么是 Zeabur？

Zeabur 是一个现代化的 Serverless 部署平台，特点：
- 🚀 自动构建和部署
- 🌍 全球 CDN 加速
- 🔒 自动 HTTPS 证书
- 💰 免费套餐支持
- 🇨🇳 对中国用户友好

## 部署前准备

### 1. 注册 Zeabur 账号

访问 [zeabur.com](https://zeabur.com) 并使用以下方式之一注册：
- GitHub 账号（推荐）
- Google 账号
- 邮箱注册

### 2. 准备 Supabase 项目

1. 访问 [supabase.com](https://supabase.com)
2. 创建新项目
3. 记录以下信息：
   - Project URL: `https://xxxxx.supabase.co`
   - Anon Key: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`

### 3. 准备 OpenAI API Key（可选）

如需 AI 对话功能：
1. 访问 [platform.openai.com](https://platform.openai.com)
2. 创建 API Key
3. 记录 Key: `sk-...`

## 部署步骤

### 方式一：通过 GitHub 部署（推荐）

#### 步骤 1：推送代码到 GitHub

```bash
# 初始化 Git 仓库
git init

# 添加所有文件
git add .

# 创建首次提交
git commit -m "Initial commit: PBL Learning Platform"

# 在 GitHub 创建新仓库后，添加远程仓库
git remote add origin https://github.com/your-username/pbl-learning.git

# 推送代码
git push -u origin main
```

#### 步骤 2：在 Zeabur 导入项目

1. 登录 [Zeabur Dashboard](https://dash.zeabur.com)
2. 点击 **"Create Project"**
3. 选择 **"Import from GitHub"**
4. 授权 Zeabur 访问你的 GitHub 账号
5. 选择 `pbl-learning` 仓库
6. 点击 **"Import"**

#### 步骤 3：配置环境变量

在项目设置页面，点击 **"Environment Variables"**，添加：

```
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
OPENAI_API_KEY=sk-...
```

**注意事项：**
- `NEXT_PUBLIC_` 开头的变量会暴露到前端
- `OPENAI_API_KEY` 不要加 `NEXT_PUBLIC_` 前缀
- 确保没有多余的空格或引号

#### 步骤 4：部署

1. 点击 **"Deploy"** 按钮
2. Zeabur 会自动：
   - 检测 Next.js 项目
   - 安装依赖 (`npm install`)
   - 构建项目 (`npm run build`)
   - 启动服务 (`npm start`)
3. 等待 2-5 分钟完成部署

#### 步骤 5：访问应用

部署成功后，你会获得一个免费域名：

```
https://your-project-name.zeabur.app
```

点击域名即可访问你的应用！

### 方式二：使用 Zeabur CLI

#### 安装 CLI

```bash
npm install -g @zeabur/cli
```

#### 登录

```bash
zeabur login
```

#### 部署

```bash
# 在项目根目录执行
zeabur deploy

# 按提示选择：
# - 创建新项目或选择现有项目
# - 输入项目名称
# - 确认部署
```

#### 配置环境变量

```bash
# 添加环境变量
zeabur env set NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
zeabur env set NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
zeabur env set OPENAI_API_KEY=sk-...

# 重新部署以应用环境变量
zeabur deploy
```

## 绑定自定义域名

### 步骤 1：在 Zeabur 添加域名

1. 进入项目设置
2. 点击 **"Domains"** 标签
3. 点击 **"Add Domain"**
4. 输入你的域名：`example.com` 或 `www.example.com`
5. 点击 **"Add"**

### 步骤 2：配置 DNS 记录

Zeabur 会显示需要添加的 DNS 记录。

#### 使用 CNAME（推荐）

在你的域名注册商（如阿里云、腾讯云、Cloudflare）添加：

```
类型: CNAME
名称: @ (根域名) 或 www (子域名)
值: cname.zeabur-dns.com
TTL: 自动或 600
```

#### 使用 A 记录

如果不支持 CNAME，使用 A 记录：

```
类型: A
名称: @
值: [Zeabur 提供的 IP 地址]
TTL: 自动或 600
```

### 步骤 3：等待 DNS 生效

- DNS 传播时间：几分钟到 48 小时
- 可以使用 [dnschecker.org](https://dnschecker.org) 检查 DNS 是否生效
- Zeabur 会自动配置 SSL 证书（Let's Encrypt）

### 步骤 4：验证

访问你的自定义域名：`https://example.com`

## 常见域名注册商配置

### 阿里云（万网）

1. 登录 [阿里云控制台](https://dns.console.aliyun.com)
2. 进入 **云解析 DNS** → **域名解析**
3. 选择你的域名，点击 **解析设置**
4. 点击 **添加记录**
5. 填写：
   ```
   记录类型: CNAME
   主机记录: @ 或 www
   记录值: cname.zeabur-dns.com
   TTL: 10分钟
   ```
6. 点击 **确认**

### 腾讯云 DNSPod

1. 登录 [DNSPod 控制台](https://console.dnspod.cn)
2. 选择你的域名
3. 点击 **添加记录**
4. 填写：
   ```
   主机记录: @ 或 www
   记录类型: CNAME
   记录值: cname.zeabur-dns.com
   TTL: 600
   ```
5. 点击 **保存**

### Cloudflare

1. 登录 [Cloudflare Dashboard](https://dash.cloudflare.com)
2. 选择你的域名
3. 进入 **DNS** 标签
4. 点击 **Add record**
5. 填写：
   ```
   Type: CNAME
   Name: @ 或 www
   Target: cname.zeabur-dns.com
   Proxy status: DNS only (灰色云朵)
   TTL: Auto
   ```
6. 点击 **Save**

**注意：** 如果使用 Cloudflare 的 CDN（橙色云朵），可能需要额外配置。

## 自动部署

### GitHub 自动部署

配置完成后，每次推送代码到 GitHub，Zeabur 会自动：
1. 检测到新提交
2. 拉取最新代码
3. 重新构建
4. 自动部署

```bash
# 修改代码后
git add .
git commit -m "Update feature"
git push

# Zeabur 会自动部署新版本
```

### 配置部署分支

默认部署 `main` 分支，可以在 Zeabur 设置中修改：
1. 进入项目设置
2. 点击 **"Git"** 标签
3. 选择要部署的分支
4. 保存

## 查看部署日志

### 在 Zeabur Dashboard

1. 进入项目页面
2. 点击 **"Deployments"** 标签
3. 选择一个部署记录
4. 查看构建日志和运行日志

### 常见日志信息

**构建成功：**
```
✓ Compiled successfully
✓ Linting and checking validity of types
✓ Collecting page data
✓ Generating static pages
✓ Finalizing page optimization
```

**运行成功：**
```
> next start
ready - started server on 0.0.0.0:3000
```

## 环境变量管理

### 添加环境变量

1. 进入项目设置
2. 点击 **"Environment Variables"**
3. 点击 **"Add Variable"**
4. 输入 Key 和 Value
5. 点击 **"Save"**
6. 重新部署以应用更改

### 环境变量最佳实践

- ✅ 使用 `NEXT_PUBLIC_` 前缀暴露到前端的变量
- ✅ API 密钥等敏感信息不要加 `NEXT_PUBLIC_` 前缀
- ✅ 在 `.env.example` 中记录所需的环境变量
- ❌ 不要在代码中硬编码敏感信息
- ❌ 不要将 `.env` 文件提交到 Git

## 性能优化

### 启用 CDN

Zeabur 默认启用全球 CDN，无需额外配置。

### 配置缓存

在 `next.config.js` 中配置：

```javascript
module.exports = {
  async headers() {
    return [
      {
        source: '/:all*(svg|jpg|png)',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable',
          },
        ],
      },
    ]
  },
}
```

### 图片优化

使用 Next.js Image 组件：

```tsx
import Image from 'next/image'

<Image
  src="/image.jpg"
  alt="Description"
  width={500}
  height={300}
/>
```

## 监控和调试

### 查看应用状态

在 Zeabur Dashboard 可以看到：
- CPU 使用率
- 内存使用
- 请求数量
- 响应时间

### 查看实时日志

```bash
# 使用 Zeabur CLI
zeabur logs --follow
```

### 调试技巧

1. **检查环境变量**
   - 在 API 路由中打印环境变量（不要打印敏感信息）
   - 确保变量名拼写正确

2. **查看构建日志**
   - 检查是否有编译错误
   - 确认依赖安装成功

3. **测试本地构建**
   ```bash
   npm run build
   npm start
   ```

## 回滚部署

如果新版本有问题，可以快速回滚：

1. 进入 **"Deployments"** 标签
2. 找到之前的成功部署
3. 点击 **"Redeploy"**
4. 确认回滚

## 成本和限制

### 免费套餐

- ✅ 无限项目
- ✅ 自动 HTTPS
- ✅ 全球 CDN
- ⚠️ 有一定的资源限制

### 付费套餐

如果需要更多资源：
- Pro Plan: $5-20/月
- 更高的 CPU 和内存
- 更多的并发请求
- 优先支持

### 资源限制

免费套餐限制：
- CPU: 0.5 vCPU
- 内存: 512MB
- 带宽: 有限制
- 构建时间: 15 分钟

## 故障排查

### 部署失败

**问题：** 构建失败
**解决：**
```bash
# 本地测试构建
npm run build

# 检查 package.json 中的 engines 字段
{
  "engines": {
    "node": ">=18.0.0"
  }
}
```

**问题：** 依赖安装失败
**解决：**
```bash
# 删除 node_modules 和 package-lock.json
rm -rf node_modules package-lock.json

# 重新安装
npm install

# 提交更新的 package-lock.json
git add package-lock.json
git commit -m "Update dependencies"
git push
```

### 运行时错误

**问题：** 环境变量未定义
**解决：**
1. 检查 Zeabur 环境变量配置
2. 确保变量名正确
3. 重新部署

**问题：** Supabase 连接失败
**解决：**
1. 检查 Supabase URL 和 Key 是否正确
2. 确认 Supabase 项目状态正常
3. 检查网络连接

### 域名问题

**问题：** 自定义域名无法访问
**解决：**
1. 使用 `nslookup your-domain.com` 检查 DNS
2. 等待 DNS 传播（最多 48 小时）
3. 检查 DNS 记录是否正确

**问题：** SSL 证书错误
**解决：**
1. 等待 Zeabur 自动配置证书（可能需要几分钟）
2. 确保 DNS 记录正确
3. 联系 Zeabur 支持

## 最佳实践

1. **使用 Git 分支管理**
   - `main` 分支用于生产环境
   - `dev` 分支用于开发环境
   - 创建多个 Zeabur 项目分别部署

2. **环境变量管理**
   - 使用 `.env.example` 记录所需变量
   - 不同环境使用不同的 Supabase 项目

3. **监控和日志**
   - 定期查看部署日志
   - 使用 Sentry 等工具监控错误

4. **性能优化**
   - 启用 Next.js 图片优化
   - 使用 ISR 或 SSG 减少服务器负载
   - 配置合理的缓存策略

## 获取帮助

- [Zeabur 文档](https://zeabur.com/docs)
- [Zeabur Discord 社区](https://discord.gg/zeabur)
- [GitHub Issues](https://github.com/zeabur/zeabur/issues)

## 总结

Zeabur 部署流程：
1. ✅ 推送代码到 GitHub
2. ✅ 在 Zeabur 导入项目
3. ✅ 配置环境变量
4. ✅ 自动部署
5. ✅ 获得免费域名
6. ✅ （可选）绑定自定义域名

整个过程只需 5-10 分钟，之后每次推送代码都会自动部署！
